/*
 * Copyright (C) 2009-2013 SAP BOBJ or an SAP affiliate company. All rights reserved
 */
jQuery.sap.declare("sap.viz.ui5.controls.PopoverRenderer");sap.viz.ui5.controls.PopoverRenderer={render:function(r,c){r.write("<div");r.writeControlData(c);r.writeClasses();r.writeStyles();r.write('>');r.write('</div>')}};
