/*!
 * SAP UI development toolkit for HTML5 (SAPUI5)
 * 
 * (c) Copyright 2009-2014 SAP AG. All rights reserved
 */
jQuery.sap.declare("sap.viz.ui5.types.controller.Interaction_pan");jQuery.sap.require("sap.viz.library");jQuery.sap.require("sap.viz.ui5.core.BaseStructuredType");sap.viz.ui5.core.BaseStructuredType.extend("sap.viz.ui5.types.controller.Interaction_pan",{metadata:{deprecated:true,library:"sap.viz",properties:{"enable":{type:"boolean",group:"",defaultValue:true},"orientation":{type:"sap.viz.ui5.types.controller.Interaction_pan_orientation",group:"",defaultValue:sap.viz.ui5.types.controller.Interaction_pan_orientation.both,deprecated:true}}}});
