/*!
 * SAP UI development toolkit for HTML5 (SAPUI5)
 * 
 * (c) Copyright 2009-2014 SAP AG. All rights reserved
 */
jQuery.sap.declare("sap.viz.ui5.DonutRenderer");jQuery.sap.require("sap.viz.ui5.core.BaseChartRenderer");sap.viz.ui5.DonutRenderer=sap.viz.ui5.core.BaseChartRenderer;
