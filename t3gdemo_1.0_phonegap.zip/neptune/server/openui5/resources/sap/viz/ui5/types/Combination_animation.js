/*!
 * SAP UI development toolkit for HTML5 (SAPUI5)
 * 
 * (c) Copyright 2009-2014 SAP AG. All rights reserved
 */
jQuery.sap.declare("sap.viz.ui5.types.Combination_animation");jQuery.sap.require("sap.viz.library");jQuery.sap.require("sap.viz.ui5.core.BaseStructuredType");sap.viz.ui5.core.BaseStructuredType.extend("sap.viz.ui5.types.Combination_animation",{metadata:{library:"sap.viz",properties:{"dataLoading":{type:"boolean",group:"",defaultValue:true},"dataUpdating":{type:"boolean",group:"",defaultValue:true},"resizing":{type:"boolean",group:"",defaultValue:true}}}});
